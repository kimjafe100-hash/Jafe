# JAFE 🔥

App ya video kama TikTok — feed, themes za rangi, likes, comments, save, repost, search, profile, na admin dashboard.

## ⚠️ Kabla Uendelee — Jambo Muhimu

App hii inatumia `localStorage` ya browser kuhifadhi akaunti na takwimu. Hii inamaanisha:
- Data inahifadhiwa **kwenye simu/kompyuta ya kila mtumiaji binafsi**, si kwenye server moja inayoshirikiwa na watu wote.
- "Jumla ya watumiaji" itaonekana tofauti kwa kila mtu kulingana na alichojisajili yeye binafsi kwenye kifaa chake.
- Ukifuta browser cache au kubadili kifaa, data inapotea.

Hii ni sawa kwa **demo na kujifunza**, lakini kwa app ya kweli inayohitaji watumiaji wote kuona namba moja sahihi (mfano "watumiaji 5,000"), utahitaji database ya kweli baadaye (kama Supabase au Firebase — bure kuanzia).

## Jinsi ya Kuiweka Online (Hatua kwa Hatua)

### Hatua 1: Pakia GitHub

1. Tembelea [github.com](https://github.com) na ujisajili (bure)
2. Bofya kitufe cha **"+"** juu kulia → **"New repository"**
3. Jina la repository: `jafe-app`
4. Bofya **"Create repository"**
5. Kwenye ukurasa unaofuata, bofya **"uploading an existing file"**
6. Pakia **folda hii nzima** (au faili zote ndani yake): `package.json`, `vite.config.js`, `index.html`, `.gitignore`, folda ya `src`, na folda ya `public`
7. Bofya **"Commit changes"**

### Hatua 2: Unganisha na Vercel

1. Tembelea [vercel.com](https://vercel.com)
2. Bofya **"Sign Up"** → chagua **"Continue with GitHub"**
3. Ruhusu Vercel ifikie akaunti yako ya GitHub
4. Kwenye dashboard ya Vercel, bofya **"Add New"** → **"Project"**
5. Chagua repository ile `jafe-app` uliyopakia
6. Vercel itatambua kiotomatiki kuwa ni Vite project — usibadilishe settings zozote
7. Bofya **"Deploy"**
8. Subiri dakika 1-2 — Vercel itakupa **link** kama `jafe-app.vercel.app`

### Hatua 3: Share Link Yako! 🎉

Link hiyo ndiyo app yako ikiwa **online**. Unaweza:
- Kuishare WhatsApp, Instagram, popote
- Mtu akiifungua kwenye simu, itaonekana kama app halisi
- Akibofya "Add to Home Screen" kwenye browser yake (Chrome/Safari), itaonekana kama icon ya app kwenye simu yake — kama imepakuliwa kutoka Play Store

## Endapo Unataka Kubadilisha Kitu

Faili kuu la app liko: `src/JafeApp.jsx`. Ukibadilisha humo na ukipakia mabadiliko GitHub, Vercel itasasisha app yako **kiotomatiki** — hauitaji kufanya chochote kingine.

## Hatua Inayofuata (Hiari)

Ukitaka data ya kweli inayoshirikiwa na watumiaji wote (database halisi badala ya localStorage), tafuta **Supabase** (supabase.com) — ina kiwango cha bure kinachokufaa vizuri kwa app ndogo/kati, na kina maelekezo rahisi ya kuunganisha na React.

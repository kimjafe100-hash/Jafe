import React from "react";
import ReactDOM from "react-dom/client";
import JafeApp from "./JafeApp.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <JafeApp />
  </React.StrictMode>
);

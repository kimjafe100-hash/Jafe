import React, { useState, useRef, useEffect, useMemo } from "react";
import {
  Heart, MessageCircle, Bookmark, Repeat2, Search, Home, User, Shield,
  Settings, Play, Pause, X, Plus, Palette, TrendingUp, Users, Video,
  LogOut, Check, ChevronLeft, Send, Lock, RefreshCw, FlaskConical, Upload, Music, Image as ImageIcon
} from "lucide-react";

/* ----------------------------- THEME SYSTEM ----------------------------- */
const THEMES = {
  inferno: { name: "Inferno", accent: "#FF2E63", accent2: "#FF6B9D", glow: "rgba(255,46,99,0.35)" },
  mint:    { name: "Mint Volt", accent: "#00F0B5", accent2: "#5CFFEA", glow: "rgba(0,240,181,0.32)" },
  violet:  { name: "Violet Static", accent: "#A855F7", accent2: "#D9A8FF", glow: "rgba(168,85,247,0.35)" },
  amber:   { name: "Amber Riot", accent: "#FFB020", accent2: "#FFD580", glow: "rgba(255,176,32,0.32)" },
  sky:     { name: "Sky Pulse", accent: "#3EC6FF", accent2: "#9FE3FF", glow: "rgba(62,198,255,0.32)" },
};

const ThemeCtx = React.createContext();
function useTheme() { return React.useContext(ThemeCtx); }

/* ----------------------------- MOCK DATA ----------------------------- */
const TOPICS = ["Dance", "Chakula", "Michezo", "Comedy", "Motisha", "Habari", "Muziki", "Throwback"];

const AVATAR_COLORS = ["#FF2E63", "#00F0B5", "#A855F7", "#FFB020", "#3EC6FF", "#FF8C42"];

function makeUser(id, name, handle, bio, isAdmin = false) {
  return {
    id, name, handle, bio, isAdmin,
    avatarColor: AVATAR_COLORS[id % AVATAR_COLORS.length],
    followers: Math.floor(400 + id * 137.7),
    following: Math.floor(50 + id * 11),
    theme: Object.keys(THEMES)[id % Object.keys(THEMES).length],
  };
}

const USERS = [
  makeUser(0, "Boss Admin", "@jafe.boss", "Founder ya JAFE 👑", true),
  makeUser(1, "Amara K.", "@amara.moves", "Dance ni lugha yangu 💃"),
  makeUser(2, "Chef Otieno", "@chefotieno", "Chakula cha mtaa, ladha ya nyumbani 🍲"),
  makeUser(3, "Zawadi", "@zawadi.motisha", "Kila siku hatua moja mbele 🔥"),
  makeUser(4, "Mtaa Sports", "@mtaasports", "Habari za michezo, papo hapo ⚽"),
  makeUser(5, "Kiki Throwback", "@kiki.tbt", "Video za zamani, kumbukumbu tamu 📼"),
  makeUser(6, "Dee Comedy", "@dee.funny", "Kicheko cha bure kila siku 😂"),
];

function makeVideo(id, userId, topic, caption) {
  const user = USERS[userId];
  return {
    id, userId, topic, caption,
    likes: Math.floor(120 + id * 311.3),
    comments: Math.floor(5 + id * 7.4),
    saves: Math.floor(2 + id * 3.1),
    reposts: Math.floor(1 + id * 2.2),
    gradientFrom: AVATAR_COLORS[id % AVATAR_COLORS.length],
    gradientTo: AVATAR_COLORS[(id + 2) % AVATAR_COLORS.length],
  };
}

const CAPTIONS_BY_TOPIC = {
  Dance: [
    "Hii beat ikicheza tu mwili unajijua 🕺",
    "Jaribu hii dance challenge na marafiki 💃",
    "Choreo mpya, mzigo mzito kweli 🔥",
    "Hatua tatu, ujue kucheza kama bingwa 😎",
    "Group dance ya wikendi, msije mkachelewa 🕺💃",
  ],
  Chakula: [
    "Pilau ya leo, recipe ya bibi yangu 😋",
    "Chai ya jioni na mandazi - tamu sana ☕",
    "Nyama choma ya mtaa, ladha asili 🔥🍖",
    "Smoothie ya asubuhi, afya kwanza 🥤",
    "Ugali na samaki, chakula cha nyumbani 😍",
  ],
  Michezo: [
    "Goli la dakika ya mwisho! Uliliona? ⚽🔥",
    "Skills za mtaani, hii ni movie 🎬⚽",
    "Mechi ya leo ilikuwa ya mwaka 🏆",
    "Training ya asubuhi, jipe moyo 💪⚽",
    "Highlight bora ya wiki hii 🔥",
  ],
  Comedy: [
    "Wacheko wa leo, jiandae kucheka 😂",
    "Skit hii itakuchekesha mpaka jioni 😂😂",
    "Prank ya kaka yangu, alishtuka kweli 😭😂",
    "POV: mama akikukumbusha mtihani 😂",
    "Hii sauti imeniua, sijawahi kucheka hivi 🤣",
  ],
  Motisha: [
    "Asubuhi ngumu? Bismillah, songa mbele 💪",
    "Usikate tamaa, leo ni siku yako 🌅",
    "Mafanikio ni mchakato, subiri tu 🔑",
    "Andika malengo yako, fanya kazi kila siku 📝",
    "Hii sauti itakuamsha roho yako leo 🙏",
  ],
  Habari: [
    "Habari mpya kutoka ligi kuu 📰",
    "Breaking: tukio kubwa limetokea leo 📢",
    "Update ya bei za mafuta wiki hii ⛽",
    "Habari za uchumi, tujue tunakoenda 📊",
    "Mabadiliko mapya serikalini, fahamu haya 🏛️",
  ],
  Muziki: [
    "Mix mpya iko nje, sikiliza hii 🎶",
    "Wimbo huu umevuma mtaa mzima 🔥🎵",
    "Cover yangu ya wimbo maarufu, sikiliza 🎤",
    "Beat mpya studio, tunaitoa wiki hii 🎧",
    "Verse hii imebeba ujumbe mzito 🎵",
  ],
  Throwback: [
    "Hii ilikuwa trend mwaka 2019 😂",
    "Replay hii mara kumi, haichoki 🔁",
    "Kumbukumbu za shule, miss this 😭❤️",
    "Throwback ya muziki wa miaka ya 2000 📼",
    "Fashion ya zamani, ilikuwa fire kweli 🔥",
  ],
};

function shuffle(arr) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function generateVideos(count = 24) {
  const pool = [];
  TOPICS.forEach((topic) => {
    CAPTIONS_BY_TOPIC[topic].forEach((caption) => pool.push({ topic, caption }));
  });
  const shuffled = shuffle(pool);
  const picks = [];
  for (let i = 0; i < count; i++) picks.push(shuffled[i % shuffled.length]);
  return shuffle(picks).map((item, i) => {
    const userId = 1 + ((i * 3 + Math.floor(Math.random() * USERS.length)) % (USERS.length - 1));
    return makeVideo(i, userId, item.topic, item.caption);
  });
}

const VIDEOS = generateVideos(24);

const COMMENT_SEED = [
  { name: "Faraja", text: "Hii ni moto kweli 🔥" },
  { name: "Neema", text: "Umenikumbusha home 😂" },
  { name: "Brian", text: "Tutorial fika basi!" },
];

/* ----------------------------- SPLASH SCREEN ----------------------------- */
function SplashScreen() {
  const theme = useTheme();
  return (
    <div style={{
      position: "absolute", inset: 0, background: "#0A0A0F", zIndex: 100,
      display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
      animation: "jafeFadeOut 2.1s forwards",
    }}>
      <style>{`
        @keyframes jafeFadeOut { 0% { opacity: 1; } 70% { opacity: 1; } 100% { opacity: 0; } }
        @keyframes jafePop { 0% { transform: scale(0.7); opacity: 0; } 60% { transform: scale(1.08); opacity: 1; } 100% { transform: scale(1); opacity: 1; } }
      `}</style>
      <h1 style={{
        fontFamily: "'Clash Display', 'Sora', sans-serif",
        fontSize: 56, fontWeight: 800, letterSpacing: "-0.03em",
        color: "#F5F5F7", margin: 0, animation: "jafePop 0.6s ease-out",
      }}>
        JAFE
      </h1>
      <p style={{ color: theme.accent, fontWeight: 600, marginTop: 10, fontSize: 13, letterSpacing: "0.06em" }}>
        KILA WIMBO, KILA HARAKA, KILA WEWE
      </p>
    </div>
  );
}

/* ----------------------------- AUTH GATE MODAL ----------------------------- */
function AuthGateModal({ onClose, onLogin, tryLoginExisting, registerNewUser }) {
  const theme = useTheme();
  const [handle, setHandle] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    if (!handle.trim() || !password.trim()) {
      setError("Jaza jina la mtumiaji na password tafadhali.");
      return;
    }
    setError("");
    setBusy(true);
    const cleanHandle = handle.startsWith("@") ? handle : "@" + handle;
    const existing = await tryLoginExisting(cleanHandle, password);
    setBusy(false);

    if (existing === "wrong_password") {
      setError("Password si sahihi kwa akaunti hii.");
      return;
    }
    if (existing) {
      onLogin(existing);
      return;
    }
    // brand new account
    if (!name.trim()) {
      setError("Akaunti mpya — weka jina lako kamili pia.");
      return;
    }
    const isAdmin = cleanHandle.replace("@", "") === "jafe.boss";
    const newAccount = { handle: cleanHandle, name, password, isAdmin };
    await registerNewUser(newAccount);
    onLogin(newAccount);
  }

  return (
    <div style={{
      position: "absolute", inset: 0, background: "rgba(0,0,0,0.7)", zIndex: 50,
      display: "flex", alignItems: "center", justifyContent: "center", padding: 20,
    }} onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} style={{
        background: "#16161D", borderRadius: 20, padding: "28px 22px", width: "100%", maxWidth: 340,
        position: "relative",
      }}>
        <X size={20} color="#9A9AA5" onClick={onClose} style={{ position: "absolute", top: 16, right: 16, cursor: "pointer" }} />
        <h3 style={{ color: "#fff", fontSize: 18, fontWeight: 700, margin: "0 0 4px" }}>Ingia au Jisajili</h3>
        <p style={{ color: "#9A9AA5", fontSize: 13, margin: "0 0 18px" }}>
          Una akaunti? Weka jina la mtumiaji na password yako ya zamani. Mpya? Jaza jina lako pia.
        </p>
        <form onSubmit={submit} style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <input placeholder="Jina la mtumiaji (handle)" value={handle} onChange={(e) => setHandle(e.target.value)} style={inputStyle()} />
          <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} style={inputStyle()} />
          <input placeholder="Jina lako (kwa akaunti mpya)" value={name} onChange={(e) => setName(e.target.value)} style={inputStyle()} />
          {error && <div style={{ color: "#FF6B6B", fontSize: 12.5 }}>{error}</div>}
          <button type="submit" disabled={busy} style={{
            background: theme.accent, color: "#0A0A0F", border: "none", borderRadius: 14,
            padding: "13px 0", fontWeight: 700, fontSize: 14.5, cursor: "pointer", marginTop: 4,
            opacity: busy ? 0.7 : 1,
          }}>
            {busy ? "Inaingia..." : "Ingia / Jisajili"}
          </button>
        </form>
      </div>
    </div>
  );
}


function inputStyle() {
  return {
    background: "#16161D", border: "1px solid #2A2A35", borderRadius: 14,
    padding: "14px 16px", color: "#F5F5F7", fontSize: 15, outline: "none",
    fontFamily: "'Sora', sans-serif",
  };
}

/* ----------------------------- VIDEO CARD ----------------------------- */
function VideoCard({ video, active, onOpenComments, liked, saved, reposted, onLike, onSave, onRepost, user, requireAuth }) {
  const theme = useTheme();
  const [playing, setPlaying] = useState(true);

  return (
    <div style={{
      position: "relative", width: "100%", height: "100%",
      background: `linear-gradient(160deg, ${video.gradientFrom}33, #0A0A0F 70%)`,
      display: "flex", alignItems: "flex-end", overflow: "hidden",
      borderRadius: 18,
    }}>
      {/* fake "video" surface */}
      <div
        onClick={() => setPlaying((p) => !p)}
        style={{
          position: "absolute", inset: 0, display: "flex",
          alignItems: "center", justifyContent: "center", cursor: "pointer",
        }}
      >
        <div style={{
          width: 120, height: 120, borderRadius: "50%",
          background: `linear-gradient(135deg, ${video.gradientFrom}, ${video.gradientTo})`,
          opacity: 0.25, filter: "blur(2px)",
        }} />
        {!playing && (
          <div style={{
            position: "absolute", width: 64, height: 64, borderRadius: "50%",
            background: "rgba(0,0,0,0.45)", display: "flex", alignItems: "center", justifyContent: "center",
          }}>
            <Play size={28} color="#fff" fill="#fff" />
          </div>
        )}
        <span style={{
          position: "absolute", top: 16, left: 16, fontSize: 11, color: "#9A9AA5",
          background: "rgba(0,0,0,0.4)", padding: "4px 10px", borderRadius: 100,
        }}>
          #{video.topic}
        </span>
      </div>

      {/* right action rail */}
      <div style={{
        position: "absolute", right: 10, bottom: 90, display: "flex",
        flexDirection: "column", alignItems: "center", gap: 18, zIndex: 2,
      }}>
        <div style={{
          width: 46, height: 46, borderRadius: "50%", background: user.avatarColor,
          display: "flex", alignItems: "center", justifyContent: "center",
          fontWeight: 700, color: "#0A0A0F", border: "2px solid #fff",
        }}>
          {user.name[0]}
        </div>
        <ActionBtn icon={Heart} active={liked} activeColor={theme.accent} count={video.likes + (liked ? 1 : 0)} onClick={() => requireAuth(onLike)} />
        <ActionBtn icon={MessageCircle} count={video.comments} onClick={() => requireAuth(onOpenComments)} />
        <ActionBtn icon={Bookmark} active={saved} activeColor={theme.accent2} count={video.saves + (saved ? 1 : 0)} onClick={() => requireAuth(onSave)} />
        <ActionBtn icon={Repeat2} active={reposted} activeColor="#00F0B5" count={video.reposts + (reposted ? 1 : 0)} onClick={() => requireAuth(onRepost)} />
      </div>

      {/* caption */}
      <div style={{ position: "relative", zIndex: 2, padding: "0 70px 22px 16px" }}>
        <div style={{ color: "#fff", fontWeight: 700, fontSize: 14, marginBottom: 4 }}>{user.handle}</div>
        <div style={{ color: "#E5E5EA", fontSize: 13.5, lineHeight: 1.4 }}>{video.caption}</div>
      </div>
    </div>
  );
}

function ActionBtn({ icon: Icon, active, activeColor = "#FF2E63", count, onClick }) {
  return (
    <button
      onClick={onClick}
      style={{
        background: "none", border: "none", display: "flex", flexDirection: "column",
        alignItems: "center", gap: 4, cursor: "pointer", color: active ? activeColor : "#fff",
      }}
    >
      <Icon size={26} fill={active ? activeColor : "none"} strokeWidth={2} />
      <span style={{ fontSize: 11, fontWeight: 600 }}>{count}</span>
    </button>
  );
}

/* ----------------------------- COMMENTS SHEET ----------------------------- */
function CommentsSheet({ video, onClose }) {
  const theme = useTheme();
  const [comments, setComments] = useState(
    COMMENT_SEED.map((c, i) => ({ ...c, id: i }))
  );
  const [text, setText] = useState("");

  function send() {
    if (!text.trim()) return;
    setComments((c) => [...c, { id: Date.now(), name: "Wewe", text }]);
    setText("");
  }

  return (
    <div style={{
      position: "absolute", inset: 0, background: "rgba(0,0,0,0.6)", zIndex: 30,
      display: "flex", alignItems: "flex-end",
    }} onClick={onClose}>
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          background: "#16161D", width: "100%", maxHeight: "65%", borderRadius: "20px 20px 0 0",
          display: "flex", flexDirection: "column", padding: "16px 0",
        }}
      >
        <div style={{ display: "flex", justifyContent: "space-between", padding: "0 16px 12px", borderBottom: "1px solid #2A2A35" }}>
          <span style={{ color: "#fff", fontWeight: 700 }}>Maoni ({comments.length})</span>
          <X size={20} color="#9A9AA5" onClick={onClose} style={{ cursor: "pointer" }} />
        </div>
        <div style={{ overflowY: "auto", padding: "12px 16px", flex: 1, display: "flex", flexDirection: "column", gap: 14 }}>
          {comments.map((c) => (
            <div key={c.id} style={{ display: "flex", gap: 10 }}>
              <div style={{
                width: 32, height: 32, borderRadius: "50%", background: theme.accent,
                flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center",
                fontWeight: 700, fontSize: 13, color: "#0A0A0F",
              }}>
                {c.name[0]}
              </div>
              <div>
                <div style={{ color: "#fff", fontSize: 13, fontWeight: 600 }}>{c.name}</div>
                <div style={{ color: "#C5C5CC", fontSize: 13.5 }}>{c.text}</div>
              </div>
            </div>
          ))}
        </div>
        <div style={{ display: "flex", gap: 8, padding: "12px 16px 4px" }}>
          <input
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && send()}
            placeholder="Andika maoni..."
            style={{ ...inputStyle(), flex: 1, padding: "10px 14px" }}
          />
          <button onClick={send} style={{
            background: theme.accent, border: "none", borderRadius: 12,
            width: 42, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer",
          }}>
            <Send size={18} color="#0A0A0F" />
          </button>
        </div>
      </div>
    </div>
  );
}

/* ----------------------------- FEED ----------------------------- */
function Feed({ videos, interactions, setInteractions, users, onRefresh, requireAuth }) {
  const theme = useTheme();
  const [openComments, setOpenComments] = useState(null);
  const containerRef = useRef(null);

  function toggle(id, key) {
    setInteractions((prev) => ({
      ...prev,
      [id]: { ...prev[id], [key]: !prev[id]?.[key] },
    }));
  }

  return (
    <div style={{ position: "relative", height: "100%" }}>
      <button
        onClick={onRefresh}
        style={{
          position: "absolute", top: 6, right: 16, zIndex: 15,
          display: "flex", alignItems: "center", gap: 6,
          background: "rgba(22,22,29,0.85)", border: `1px solid ${theme.accent}55`,
          borderRadius: 100, padding: "6px 12px", color: theme.accent,
          fontSize: 11.5, fontWeight: 600, cursor: "pointer",
        }}
      >
        <RefreshCw size={13} /> Video Mpya
      </button>
      <div
        ref={containerRef}
        style={{
          height: "100%", overflowY: "auto", scrollSnapType: "y mandatory",
          display: "flex", flexDirection: "column", gap: 10, padding: "10px 10px 0",
        }}
      >
        {videos.map((v) => {
          const inter = interactions[v.id] || {};
          const user = users.find((u) => u.id === v.userId);
          return (
            <div key={v.id} style={{ height: "calc(100% - 10px)", flexShrink: 0, scrollSnapAlign: "start", position: "relative" }}>
              <VideoCard
                video={v}
                user={user}
                liked={!!inter.liked}
                saved={!!inter.saved}
                reposted={!!inter.reposted}
                onLike={() => toggle(v.id, "liked")}
                onSave={() => toggle(v.id, "saved")}
                onRepost={() => toggle(v.id, "reposted")}
                onOpenComments={() => setOpenComments(v.id)}
                requireAuth={requireAuth}
              />
              {openComments === v.id && (
                <CommentsSheet video={v} onClose={() => setOpenComments(null)} />
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ----------------------------- SEARCH ----------------------------- */
function SearchPage({ users, videos }) {
  const theme = useTheme();
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("Zote");

  const filtered = useMemo(() => {
    return videos.filter((v) => {
      const topicMatch = filter === "Zote" || v.topic === filter;
      const qMatch = !query || v.caption.toLowerCase().includes(query.toLowerCase()) || v.topic.toLowerCase().includes(query.toLowerCase());
      return topicMatch && qMatch;
    });
  }, [query, filter, videos]);

  return (
    <div style={{ height: "100%", overflowY: "auto", padding: "16px 16px 90px" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, background: "#16161D", borderRadius: 14, padding: "10px 14px", marginBottom: 14 }}>
        <Search size={18} color="#9A9AA5" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search dance, chakula, michezo..."
          style={{ background: "none", border: "none", outline: "none", color: "#fff", fontSize: 14, flex: 1 }}
        />
      </div>
      <div style={{ display: "flex", gap: 8, overflowX: "auto", paddingBottom: 14 }}>
        {["Zote", ...TOPICS].map((t) => (
          <button
            key={t}
            onClick={() => setFilter(t)}
            style={{
              flexShrink: 0, padding: "7px 14px", borderRadius: 100, fontSize: 13, fontWeight: 600,
              border: "none", cursor: "pointer",
              background: filter === t ? theme.accent : "#16161D",
              color: filter === t ? "#0A0A0F" : "#C5C5CC",
            }}
          >
            {t}
          </button>
        ))}
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
        {filtered.map((v) => (
          <div key={v.id} style={{
            aspectRatio: "9/14", borderRadius: 14, position: "relative", overflow: "hidden",
            background: `linear-gradient(160deg, ${v.gradientFrom}55, #0A0A0F 80%)`,
            display: "flex", alignItems: "flex-end", padding: 10,
          }}>
            <span style={{ position: "absolute", top: 8, left: 8, fontSize: 10, background: "rgba(0,0,0,0.5)", color: "#fff", padding: "3px 8px", borderRadius: 100 }}>#{v.topic}</span>
            <div style={{ display: "flex", alignItems: "center", gap: 4, color: "#fff", fontSize: 12 }}>
              <Heart size={13} fill="#fff" /> {v.likes}
            </div>
          </div>
        ))}
        {filtered.length === 0 && (
          <div style={{ gridColumn: "1/-1", textAlign: "center", color: "#6A6A75", marginTop: 40 }}>
            Hakuna video iliyopatikana. Jaribu neno lingine.
          </div>
        )}
      </div>
    </div>
  );
}

/* ----------------------------- THEME PICKER ----------------------------- */
function ThemePicker({ currentKey, onPick }) {
  return (
    <div style={{ display: "flex", gap: 12, flexWrap: "wrap", padding: "4px 0" }}>
      {Object.entries(THEMES).map(([key, t]) => (
        <button
          key={key}
          onClick={() => onPick(key)}
          style={{
            display: "flex", flexDirection: "column", alignItems: "center", gap: 6,
            background: "none", border: "none", cursor: "pointer",
          }}
        >
          <div style={{
            width: 46, height: 46, borderRadius: "50%",
            background: `linear-gradient(135deg, ${t.accent}, ${t.accent2})`,
            border: currentKey === key ? "3px solid #fff" : "3px solid transparent",
            display: "flex", alignItems: "center", justifyContent: "center",
          }}>
            {currentKey === key && <Check size={18} color="#0A0A0F" strokeWidth={3} />}
          </div>
          <span style={{ fontSize: 10.5, color: "#9A9AA5" }}>{t.name}</span>
        </button>
      ))}
    </div>
  );
}

/* ----------------------------- UPLOAD MODAL ----------------------------- */
function UploadModal({ onClose, onUpload }) {
  const theme = useTheme();
  const [kind, setKind] = useState("video");
  const [caption, setCaption] = useState("");
  const [fileName, setFileName] = useState("");
  const fileInputRef = useRef(null);

  const acceptMap = { video: "video/*", picha: "image/*", wimbo: "audio/*" };
  const iconMap = { video: Video, picha: ImageIcon, wimbo: Music };
  const Icon = iconMap[kind];

  function handleFile(e) {
    const f = e.target.files?.[0];
    if (f) setFileName(f.name);
  }

  function submit() {
    if (!fileName) return;
    onUpload({ kind, caption: caption || fileName, fileName });
  }

  return (
    <div style={{
      position: "absolute", inset: 0, background: "rgba(0,0,0,0.7)", zIndex: 50,
      display: "flex", alignItems: "center", justifyContent: "center", padding: 20,
    }} onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} style={{
        background: "#16161D", borderRadius: 20, padding: "24px 22px", width: "100%", maxWidth: 340, position: "relative",
      }}>
        <X size={20} color="#9A9AA5" onClick={onClose} style={{ position: "absolute", top: 16, right: 16, cursor: "pointer" }} />
        <h3 style={{ color: "#fff", fontSize: 17, fontWeight: 700, margin: "0 0 14px" }}>Pakia Maudhui Mapya</h3>

        <div style={{ display: "flex", gap: 8, marginBottom: 16 }}>
          {["video", "picha", "wimbo"].map((k) => (
            <button key={k} onClick={() => { setKind(k); setFileName(""); }} style={{
              flex: 1, padding: "9px 0", borderRadius: 10, border: "none", cursor: "pointer",
              fontSize: 12.5, fontWeight: 600, textTransform: "capitalize",
              background: kind === k ? theme.accent : "#101015",
              color: kind === k ? "#0A0A0F" : "#9A9AA5",
            }}>
              {k}
            </button>
          ))}
        </div>

        <button
          onClick={() => fileInputRef.current?.click()}
          style={{
            width: "100%", border: `1.5px dashed ${fileName ? theme.accent : "#2A2A35"}`, borderRadius: 14,
            padding: "22px 10px", background: "none", cursor: "pointer",
            display: "flex", flexDirection: "column", alignItems: "center", gap: 8,
          }}
        >
          <Icon size={24} color={fileName ? theme.accent : "#6A6A75"} />
          <span style={{ color: fileName ? "#fff" : "#6A6A75", fontSize: 12.5, textAlign: "center" }}>
            {fileName || `Chagua ${kind} kutoka kifaa chako`}
          </span>
        </button>
        <input ref={fileInputRef} type="file" accept={acceptMap[kind]} onChange={handleFile} style={{ display: "none" }} />

        <input
          placeholder="Andika caption..."
          value={caption}
          onChange={(e) => setCaption(e.target.value)}
          style={{ ...inputStyle(), width: "100%", marginTop: 14 }}
        />

        <button
          onClick={submit}
          disabled={!fileName}
          style={{
            width: "100%", marginTop: 14, background: fileName ? theme.accent : "#2A2A35",
            color: fileName ? "#0A0A0F" : "#6A6A75", border: "none", borderRadius: 14,
            padding: "12px 0", fontWeight: 700, fontSize: 14, cursor: fileName ? "pointer" : "default",
          }}
        >
          Chapisha
        </button>
      </div>
    </div>
  );
}

/* ----------------------------- PROFILE PAGE ----------------------------- */
function ProfilePage({ profileUser, isOwn, themeKey, onThemeChange, myVideos, savedVideos, repostedVideos, users, myUploads = [], onUpload }) {
  const theme = useTheme();
  const [tab, setTab] = useState("posts");
  const [showThemes, setShowThemes] = useState(false);
  const [showUpload, setShowUpload] = useState(false);

  const tabVideos = tab === "posts" ? myVideos : tab === "saved" ? savedVideos : repostedVideos;

  return (
    <div style={{ height: "100%", overflowY: "auto", padding: "20px 18px 90px", position: "relative" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
        <div style={{
          width: 78, height: 78, borderRadius: "50%", background: profileUser.avatarColor,
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 28, fontWeight: 800, color: "#0A0A0F", flexShrink: 0,
        }}>
          {profileUser.name[0]}
        </div>
        <div>
          <div style={{ color: "#fff", fontWeight: 700, fontSize: 18 }}>{profileUser.name}</div>
          <div style={{ color: theme.accent, fontSize: 13.5 }}>{profileUser.handle}</div>
          {profileUser.isAdmin && (
            <span style={{ display: "inline-flex", alignItems: "center", gap: 4, fontSize: 11, color: "#0A0A0F", background: theme.accent, borderRadius: 100, padding: "2px 8px", marginTop: 4, fontWeight: 700 }}>
              <Shield size={11} /> BOSS
            </span>
          )}
        </div>
      </div>

      <p style={{ color: "#C5C5CC", fontSize: 13.5, marginTop: 14, lineHeight: 1.5 }}>{profileUser.bio}</p>

      <div style={{ display: "flex", gap: 22, marginTop: 16 }}>
        <Stat label="Wanaofuata" value={profileUser.followers} />
        <Stat label="Anaofuata" value={profileUser.following} />
        <Stat label="Posts" value={myVideos.length + myUploads.length} />
      </div>

      {isOwn && (
        <div style={{ display: "flex", gap: 8, marginTop: 18 }}>
          <button
            onClick={() => setShowUpload(true)}
            style={{
              flex: 1, display: "flex", alignItems: "center", gap: 8, justifyContent: "center",
              background: theme.accent, border: "none", borderRadius: 12,
              padding: "10px 14px", color: "#0A0A0F", fontSize: 13.5, fontWeight: 700, cursor: "pointer",
            }}
          >
            <Upload size={15} /> Pakia
          </button>
          <button
            onClick={() => setShowThemes((s) => !s)}
            style={{
              flex: 1, display: "flex", alignItems: "center", gap: 8, justifyContent: "center",
              background: "#16161D", border: "1px solid #2A2A35", borderRadius: 12,
              padding: "10px 14px", color: "#fff", fontSize: 13.5, fontWeight: 600, cursor: "pointer",
            }}
          >
            <Palette size={15} color={theme.accent} /> Theme
          </button>
        </div>
      )}
      {isOwn && showThemes && (
        <div style={{ marginTop: 12, background: "#101015", borderRadius: 14, padding: "12px 14px" }}>
          <ThemePicker currentKey={themeKey} onPick={onThemeChange} />
        </div>
      )}

      <div style={{ display: "flex", gap: 6, marginTop: 22, borderBottom: "1px solid #2A2A35" }}>
        <TabBtn label="Posts" active={tab === "posts"} onClick={() => setTab("posts")} accent={theme.accent} />
        <TabBtn label="Saved" active={tab === "saved"} onClick={() => setTab("saved")} accent={theme.accent} />
        <TabBtn label="Reposts" active={tab === "reposts"} onClick={() => setTab("reposts")} accent={theme.accent} />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginTop: 14 }}>
        {tab === "posts" && myUploads.map((u) => {
          const Icon = u.kind === "wimbo" ? Music : u.kind === "picha" ? ImageIcon : Video;
          return (
            <div key={u.id} style={{
              aspectRatio: "9/14", borderRadius: 10, position: "relative", overflow: "hidden",
              background: `linear-gradient(160deg, ${theme.accent}33, #0A0A0F 80%)`,
              display: "flex", alignItems: "center", justifyContent: "center",
            }}>
              <Icon size={22} color={theme.accent} style={{ opacity: 0.7 }} />
              <div style={{ position: "absolute", bottom: 5, left: 5, right: 5, fontSize: 9.5, color: "#fff" }}>
                {u.caption.slice(0, 22)}
              </div>
            </div>
          );
        })}
        {tabVideos.map((v) => (
          <div key={v.id} style={{
            aspectRatio: "9/14", borderRadius: 10, position: "relative", overflow: "hidden",
            background: `linear-gradient(160deg, ${v.gradientFrom}55, #0A0A0F 80%)`,
          }}>
            <div style={{ position: "absolute", bottom: 5, left: 5, fontSize: 10, color: "#fff", display: "flex", alignItems: "center", gap: 3 }}>
              <Heart size={10} fill="#fff" /> {v.likes}
            </div>
          </div>
        ))}
        {tabVideos.length === 0 && (tab !== "posts" || myUploads.length === 0) && (
          <div style={{ gridColumn: "1/-1", textAlign: "center", color: "#6A6A75", marginTop: 30, fontSize: 13 }}>
            {tab === "posts" ? "Hujapakia chochote bado. Bofya Pakia kuanza! 🚀" : "Hakuna bado hapa."}
          </div>
        )}
      </div>

      {showUpload && (
        <UploadModal
          onClose={() => setShowUpload(false)}
          onUpload={(item) => { onUpload(item); setShowUpload(false); }}
        />
      )}
    </div>
  );
}

function Stat({ label, value }) {
  return (
    <div>
      <div style={{ color: "#fff", fontWeight: 700, fontSize: 16 }}>{value}</div>
      <div style={{ color: "#8A8A95", fontSize: 11.5 }}>{label}</div>
    </div>
  );
}

function TabBtn({ label, active, onClick, accent }) {
  return (
    <button
      onClick={onClick}
      style={{
        flex: 1, background: "none", border: "none", padding: "10px 0",
        color: active ? accent : "#7A7A85", fontWeight: 600, fontSize: 13,
        borderBottom: active ? `2px solid ${accent}` : "2px solid transparent", cursor: "pointer",
      }}
    >
      {label}
    </button>
  );
}

/* ----------------------------- ADMIN DASHBOARD ----------------------------- */
function AdminDashboard({ users, videos, globalStats }) {
  const theme = useTheme();
  const totalLikes = videos.reduce((s, v) => s + v.likes, 0);
  const totalComments = videos.reduce((s, v) => s + v.comments, 0);
  const topVideos = [...videos].sort((a, b) => b.likes - a.likes).slice(0, 5);

  return (
    <div style={{ height: "100%", overflowY: "auto", padding: "20px 18px 90px" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
        <Shield size={20} color={theme.accent} />
        <h2 style={{ color: "#fff", fontSize: 19, fontWeight: 700, margin: 0 }}>Admin Dashboard</h2>
      </div>
      <p style={{ color: "#7A7A85", fontSize: 12.5, marginBottom: 18 }}>
        Takwimu za jumla za app. Admin haoni post au ujumbe wa faragha wa watumiaji binafsi.
      </p>

      <div style={{
        background: `linear-gradient(135deg, ${theme.accent}22, #16161D 70%)`,
        border: `1px solid ${theme.accent}55`, borderRadius: 16, padding: "16px 18px", marginBottom: 16,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
          <FlaskConical size={17} color={theme.accent} />
          <span style={{ color: "#fff", fontWeight: 700, fontSize: 14.5 }}>JAFE Laboratory</span>
        </div>
        <div style={{ display: "flex", gap: 24 }}>
          <div>
            <div style={{ color: theme.accent, fontSize: 26, fontWeight: 800 }}>{globalStats.totalUsers.toLocaleString()}</div>
            <div style={{ color: "#9A9AA5", fontSize: 11.5 }}>Watumiaji wote (CEO view)</div>
          </div>
          <div>
            <div style={{ color: theme.accent2, fontSize: 26, fontWeight: 800 }}>{globalStats.totalViews.toLocaleString()}</div>
            <div style={{ color: "#9A9AA5", fontSize: 11.5 }}>Views jumla, watu wote</div>
          </div>
        </div>
        <p style={{ color: "#7A7A85", fontSize: 11, marginTop: 10, marginBottom: 0 }}>
          Hii inakusanya data kutoka kwa watumiaji wote wanaotumia JAFE kwa sasa, ikiwa ni pamoja na akaunti mpya zinazojisajili.
        </p>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
        <StatCard icon={Users} label="Watumiaji (demo)" value={users.length} color={theme.accent} />
        <StatCard icon={Video} label="Posts Jumla" value={videos.length} color={theme.accent2} />
        <StatCard icon={Heart} label="Likes Jumla" value={totalLikes} color="#FF6B9D" />
        <StatCard icon={MessageCircle} label="Maoni Jumla" value={totalComments} color="#00F0B5" />
      </div>

      <h3 style={{ color: "#fff", fontSize: 15, marginTop: 24, marginBottom: 10 }}>Video Zinazoshamiri</h3>
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {topVideos.map((v, i) => (
          <div key={v.id} style={{
            display: "flex", alignItems: "center", gap: 12, background: "#16161D",
            borderRadius: 12, padding: "10px 14px",
          }}>
            <span style={{ color: theme.accent, fontWeight: 800, fontSize: 14, width: 18 }}>{i + 1}</span>
            <div style={{
              width: 40, height: 40, borderRadius: 8,
              background: `linear-gradient(160deg, ${v.gradientFrom}, ${v.gradientTo})`,
            }} />
            <div style={{ flex: 1 }}>
              <div style={{ color: "#fff", fontSize: 12.5 }}>{v.caption.slice(0, 30)}...</div>
              <div style={{ color: "#7A7A85", fontSize: 11 }}>#{v.topic}</div>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 4, color: "#fff", fontSize: 12.5 }}>
              <Heart size={13} fill={theme.accent} color={theme.accent} /> {v.likes}
            </div>
          </div>
        ))}
      </div>

      <div style={{
        marginTop: 22, background: "#16161D", border: `1px solid ${theme.accent}40`, borderRadius: 14,
        padding: "14px 16px",
      }}>
        <div style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 6 }}>
          <Lock size={14} color={theme.accent} />
          <span style={{ color: "#fff", fontSize: 13, fontWeight: 700 }}>Sera ya Admin</span>
        </div>
        <p style={{ color: "#9A9AA5", fontSize: 12, lineHeight: 1.5, margin: 0 }}>
          Kwa kulinda faragha ya watumiaji, admin haina uwezo wa kuingia kwenye akaunti binafsi za watu
          au kubadilisha likes/maoni yao moja kwa moja. Dashboard hii inaonyesha takwimu za jumla tu.
        </p>
      </div>
    </div>
  );
}

function StatCard({ icon: Icon, label, value, color }) {
  return (
    <div style={{ background: "#16161D", borderRadius: 14, padding: "14px 14px" }}>
      <Icon size={18} color={color} />
      <div style={{ color: "#fff", fontSize: 20, fontWeight: 800, marginTop: 8 }}>{value.toLocaleString()}</div>
      <div style={{ color: "#7A7A85", fontSize: 11.5 }}>{label}</div>
    </div>
  );
}

/* ----------------------------- BOTTOM NAV ----------------------------- */
function BottomNav({ active, setActive, isAdmin }) {
  const theme = useTheme();
  const items = [
    { key: "feed", icon: Home, label: "Nyumbani" },
    { key: "search", icon: Search, label: "Search" },
    { key: "profile", icon: User, label: "Profile" },
    ...(isAdmin ? [{ key: "admin", icon: Shield, label: "Admin" }] : []),
  ];
  return (
    <div style={{
      position: "absolute", bottom: 0, left: 0, right: 0, height: 64,
      background: "#0F0F14", borderTop: "1px solid #1F1F28",
      display: "flex", alignItems: "center", justifyContent: "space-around", zIndex: 10,
    }}>
      {items.map((it) => {
        const isActive = active === it.key;
        return (
          <button
            key={it.key}
            onClick={() => setActive(it.key)}
            style={{
              background: "none", border: "none", display: "flex", flexDirection: "column",
              alignItems: "center", gap: 3, cursor: "pointer", color: isActive ? theme.accent : "#6A6A75",
            }}
          >
            <it.icon size={21} />
            <span style={{ fontSize: 10, fontWeight: 600 }}>{it.label}</span>
          </button>
        );
      })}
    </div>
  );
}

/* ----------------------------- MAIN APP ----------------------------- */
export default function JafeApp() {
  const [showSplash, setShowSplash] = useState(true);
  const [loggedIn, setLoggedIn] = useState(false);
  const [me, setMe] = useState(null);
  const [themeKey, setThemeKey] = useState("inferno");
  const [tab, setTab] = useState("feed");
  const [interactions, setInteractions] = useState({});
  const [videos, setVideos] = useState(VIDEOS);
  const [showAuthGate, setShowAuthGate] = useState(false);
  const [pendingAction, setPendingAction] = useState(null);
  const [globalStats, setGlobalStats] = useState({ totalUsers: USERS.length, totalViews: 48210 });
  const [myUploads, setMyUploads] = useState([]);

  const theme = THEMES[themeKey];

  useEffect(() => {
    const t = setTimeout(() => setShowSplash(false), 1900);
    return () => clearTimeout(t);
  }, []);

  // Load shared global stats once on mount
  useEffect(() => {
    try {
      const raw = localStorage.getItem("jafe:global-stats");
      if (raw) {
        setGlobalStats(JSON.parse(raw));
      } else {
        localStorage.setItem("jafe:global-stats", JSON.stringify({ totalUsers: USERS.length, totalViews: 48210 }));
      }
    } catch (e) {
      // storage unavailable, keep local defaults
    }
  }, []);

  // Count a "view" once per session on the feed
  useEffect(() => {
    try {
      const raw = localStorage.getItem("jafe:global-stats");
      const current = raw ? JSON.parse(raw) : globalStats;
      const updated = { ...current, totalViews: current.totalViews + 1 };
      localStorage.setItem("jafe:global-stats", JSON.stringify(updated));
      setGlobalStats(updated);
    } catch (e) {}
  }, []);

  function refreshFeed() {
    setVideos(generateVideos(24));
    setInteractions({});
  }

  function requireAuth(action) {
    if (loggedIn) {
      action();
    } else {
      setPendingAction(() => action);
      setShowAuthGate(true);
    }
  }

  async function registerNewUser(data) {
    // Save account so the same name+password combo can log back in later
    try {
      const key = "jafe:account:" + data.handle.toLowerCase();
      localStorage.setItem(key, JSON.stringify({ name: data.name, password: data.password, isAdmin: data.isAdmin }));
      const raw = localStorage.getItem("jafe:global-stats");
      const stats = raw ? JSON.parse(raw) : globalStats;
      const updated = { ...stats, totalUsers: stats.totalUsers + 1 };
      localStorage.setItem("jafe:global-stats", JSON.stringify(updated));
      setGlobalStats(updated);
    } catch (e) {}
  }

  async function tryLoginExisting(handle, password) {
    try {
      const key = "jafe:account:" + handle.toLowerCase();
      const raw = localStorage.getItem(key);
      if (raw) {
        const acct = JSON.parse(raw);
        if (acct.password === password) {
          return { name: acct.name, handle, isAdmin: acct.isAdmin };
        }
        return "wrong_password";
      }
      return null; // no existing account, treat as new signup
    } catch (e) {
      return null;
    }
  }

  function handleLogin(data) {
    setMe(data);
    if (data.isAdmin) setThemeKey("inferno");
    setLoggedIn(true);
    setShowAuthGate(false);
    if (pendingAction) {
      pendingAction();
      setPendingAction(null);
    }
  }

  function handleUpload(item) {
    setMyUploads((prev) => [{ id: Date.now(), ...item }, ...prev]);
  }

  function handleLogout() {
    setLoggedIn(false);
    setMe(null);
    setTab("feed");
  }

  function goToTab(key) {
    if ((key === "profile" || key === "admin") && !loggedIn) {
      setPendingAction(() => () => setTab(key));
      setShowAuthGate(true);
      return;
    }
    setTab(key);
  }

  const myProfile = useMemo(() => {
    if (!me) return USERS[0];
    return {
      id: 99,
      name: me.name,
      handle: me.handle,
      bio: "Karibu kwenye profile yangu ya JAFE ✨",
      isAdmin: me.isAdmin,
      avatarColor: AVATAR_COLORS[me.handle.length % AVATAR_COLORS.length],
      followers: 12,
      following: 8,
    };
  }, [me]);

  const savedVideos = videos.filter((v) => interactions[v.id]?.saved);
  const repostedVideos = videos.filter((v) => interactions[v.id]?.reposted);
  const myVideos = []; // new user has no posts yet

  return (
    <ThemeCtx.Provider value={theme}>
      <FontImports />
      <div style={{
        width: "100%", maxWidth: 420, height: "100vh", maxHeight: 880, margin: "0 auto",
        background: "#0A0A0F", position: "relative", overflow: "hidden",
        fontFamily: "'Sora', sans-serif", borderRadius: 0,
        boxShadow: "0 0 60px rgba(0,0,0,0.5)",
      }}>
        {showSplash && <SplashScreen />}

        {/* top bar */}
        <div style={{
          position: "absolute", top: 0, left: 0, right: 0, height: 52, zIndex: 10,
          display: "flex", alignItems: "center", justifyContent: "space-between",
          padding: "0 16px", background: tab === "feed" ? "linear-gradient(180deg, rgba(0,0,0,0.6), transparent)" : "#0A0A0F",
        }}>
          <span style={{
            fontFamily: "'Clash Display', 'Sora', sans-serif", fontWeight: 800, fontSize: 17, color: "#fff", letterSpacing: "-0.02em",
          }}>
            JAFE
          </span>
          {loggedIn ? (
            <button onClick={handleLogout} style={{ background: "none", border: "none", cursor: "pointer", color: "#9A9AA5", display: "flex", alignItems: "center", gap: 4, fontSize: 12 }}>
              <LogOut size={15} /> Toka
            </button>
          ) : (
            <button onClick={() => requireAuth(() => {})} style={{
              background: theme.accent, border: "none", borderRadius: 100, cursor: "pointer",
              color: "#0A0A0F", fontSize: 12, fontWeight: 700, padding: "6px 14px",
            }}>
              Jisajili
            </button>
          )}
        </div>

        <div style={{ position: "absolute", top: 52, left: 0, right: 0, bottom: 64 }}>
          {tab === "feed" && (
            <Feed videos={videos} interactions={interactions} setInteractions={setInteractions} users={USERS} onRefresh={refreshFeed} requireAuth={requireAuth} />
          )}
          {tab === "search" && <SearchPage users={USERS} videos={videos} />}
          {tab === "profile" && loggedIn && (
            <ProfilePage
              profileUser={myProfile}
              isOwn
              themeKey={themeKey}
              onThemeChange={setThemeKey}
              myVideos={myVideos}
              savedVideos={savedVideos}
              repostedVideos={repostedVideos}
              users={USERS}
              myUploads={myUploads}
              onUpload={handleUpload}
            />
          )}
          {tab === "admin" && me?.isAdmin && <AdminDashboard users={USERS} videos={videos} globalStats={globalStats} />}
        </div>

        <BottomNav active={tab} setActive={goToTab} isAdmin={me?.isAdmin} />

        {showAuthGate && (
          <AuthGateModal
            onClose={() => { setShowAuthGate(false); setPendingAction(null); }}
            onLogin={handleLogin}
            tryLoginExisting={tryLoginExisting}
            registerNewUser={registerNewUser}
          />
        )}
      </div>
    </ThemeCtx.Provider>
  );
}

function FontImports() {
  return (
    <style>{`
      @import url('https://fonts.googleapis.com/css2?family=Sora:wght@400;500;600;700;800&display=swap');
      * { box-sizing: border-box; }
      body { margin: 0; }
      ::-webkit-scrollbar { width: 0; height: 0; }
    `}</style>
  );
}
